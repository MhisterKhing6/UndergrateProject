public class Question {
public static int largestInteger(int a , int b) {
    if(a > b) 
        return a;
    else 
        return b;
}
}